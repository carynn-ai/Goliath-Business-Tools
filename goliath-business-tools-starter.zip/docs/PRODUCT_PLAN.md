# Product plan

## Goal
Internal tools for Goliath business operations.

## Scope
Operational tools for class scheduling, lead tracking, customer follow-up, and reporting. Avoid storing customer information or credentials in Git.

## First milestone
- Choose a technology stack and document tradeoffs.
- Identify data sources, access limits, and privacy considerations.
- Build one working flow with clear tests.
- Write setup and deployment instructions.

## Not yet implemented
The current repository is a scaffold only.
